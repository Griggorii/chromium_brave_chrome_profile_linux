https://github.com/Griggorii/chromium_brave_chrome_profile_linux

Bookmark passwd backup ! Script version browser run , restart browser

Terminal run command google-chrome profile install run chrome browser run click Google-chrome.sh and command

./Google-chrome.sh

------------------------------------------------------

Terminal run command chromium profile install run chromium browser run click Chromium.sh and command

./Chromium.sh

------------------------------------------------------

Terminal run command Brave-Browser profile install run brave browser run click Brave-Browser.sh and command

./Brave-Browser.sh

