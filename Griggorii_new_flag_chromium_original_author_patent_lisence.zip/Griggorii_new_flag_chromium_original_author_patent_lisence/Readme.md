                               Griggorii@gmail.com license groups tabs containers activate color tabs youtube


1) Install all profile + Default folder https://github.com/Griggorii/chromium_brave_chrome_profile_linux download https://yadi.sk/d/9E_mcAo75Qo22Q  Default folder install

2) Folder in run terminal locate Local State file , browser closed

Terminal run command google-chrome profile install run chrome browser

cp 'Local State' ~/.config/google-chrome
______________________________________________________________________________________
Terminal run command chromium profile install run chromium browser

cp 'Local State' ~/.config/chromium
__________________________________________________________________________________
Terminal run command Brave-Browser profile install run brave browser

cp 'Local State' ~/.config//BraveSoftware/Brave-Browser